

### Execution Sequence: 
## Chunking Service provided as chunker.py 
## Chunking service to get text content as input, and 
## return iterator over the fixed length chunks generated 
# REFER File Snippet 1 :  


## Text Extraction Service provided as extractor.py 
## Service uses standard py packages Py2PDF to 
## extract text content from PDF documents and 
## shares the file content in a stringified format 
# REFER File Snippet 2 :  

## Summarizing Service provided as summa.py 
## Service accepts the section of interest [chunk] 
## to be summarized 
# REFER File Snippet 3 :  


## ENV vars to create" 

INPUT_PATH : BLOB_STORAGE path or INPUT_FOLDER_LOC
OPENAI_ENDPOINT: 
OPENAI_API_KEY: 
OPENAI_API_VERSION: 
CHUNK_SIZE_FOR_SPLITTING: 

### config file to be maintain the prompt and 
### prompt parameters & manage versions 
    prompt
    model 
    temp 
    top_p 
    max_tokens 
    threshold 
